from odoo import fields, models, api, _

  
class AccountAcountInherit(models.Model):
    _inherit = 'account.account'
    is_related=fields.Boolean("Is related company account")
    

    
    
    

     
    
    
