from odoo import fields, models, api, _
    
    
class AccountJournalInherit(models.Model):
    _inherit = 'account.journal'
    is_related=fields.Boolean("is related company jounral")
    
    
    

     
    
    
