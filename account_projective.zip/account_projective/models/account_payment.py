from odoo import fields, models, api, _

  
class AccountPaymentInherit(models.Model):
    _inherit = 'account.payment'
    account_child_ids = fields.One2many('account.payment.child', 'account_invoice_id', string="Invoices")    

    @api.onchange('partner_id')
    def payment_records(self):
        all=self.env['account.move'].search([('partner_id','=',self.partner_id.id),('move_type', '=', 'out_invoice'),('invoice_date', '=', self.date)])
        print("PPPPPPPPPPPPPPP : ",all)
        all_objs = [] 
        self.account_child_ids = [(5, 0, 0)]
        for a in all:
            invoice_data = {
                'date': a.invoice_date,
                'company_id': a.company_id.id,
                'invoice_id': a.id,
                'invoice_amount': a.amount_total_signed,
                'bal_amount': a.amount_residual,
            }
            all_objs.append((0, 0, invoice_data)) 
        self.account_child_ids=all_objs

    
    
class AccountPaymentChild(models.Model):
    _name = 'account.payment.child'
    account_invoice_id = fields.Many2one('account.payment', string="Invoices")
   
    date = fields.Date( string="Date")
    company_id = fields.Many2one('res.company', string="Company")
    invoice_id = fields.Many2one('account.move', string="Invoice")
    invoice_amount = fields.Integer(string="Invoice Amount")
    bal_amount = fields.Integer(string="Balance Amount")
    reconclied = fields.Integer(string="Reconclied")
    
  
    


    

    
    
    

     
    
    
