from odoo import fields, models, api, _

class BillAccountingResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

   
    related_account = fields.Many2one('account.account',string="Related Account",config_parameter='help.related_account',
                                      domain=[('is_related', '=', True)]                                
                                      )

    

    
    
    

     
    
    
