# -*- coding: utf-8 -*-
{
    'name': "Account Projective",

    'summary': """
    In this module we are adding some fields in accountning module
        """,

    'description': """
       in this module we are adding some fields in accountning module
    """,

    
    'author': "Hamayun Fazal",
    'website': "http://www.projective.com",

    # Categories can be used to filter modules in modules listing
    # Check https://gitlab.com/flectra-hq/flectra/blob/2.0/flectra/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['account'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/config_setting.xml',
        'views/account_account.xml',
        'views/account_journal.xml',
        'views/account_payment.xml',

    ],
    
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'AGPL-3',
   
}
